package com.example;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String s[]) {

		new ClassPathXmlApplicationContext("bridge-conf.xml");
		System.out.println("System is running!!!!");

	}
}