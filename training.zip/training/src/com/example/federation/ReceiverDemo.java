package com.example.federation;

import java.io.IOException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.rabbitmq.client.AMQP.BasicProperties;

public class ReceiverDemo {

	public static void main(String[] args) throws Exception {
		new ReceiverDemo();
	}

	public ReceiverDemo() throws Exception {

		ConnectionFactory connectionFactory = new ConnectionFactory();
		connectionFactory.setHost("localhost");
		connectionFactory.setPort(5673); //Slave Node
		connectionFactory.setVirtualHost("Domminoz");
		connectionFactory.setUsername("guest");
		connectionFactory.setPassword("guest");
	
		Connection connection = connectionFactory.newConnection();
		System.out.println("Connected to Broker!!!!");

		Channel channel = connection.createChannel();

		MessageConsumer consumer = new MessageConsumer(channel);

		String QUEUE = "Q.SmallOrders";
		channel.basicConsume(QUEUE, true, consumer);

		// Step 6
		// Close/Release channel and connection
		//channel.close();
		//connection.close();
		System.out.println("Disconnected from Broker!!!!");

	}

	class MessageConsumer extends DefaultConsumer {

		public MessageConsumer(Channel channel) {
			super(channel);
		}

		public void handleDelivery(String consumerTag, Envelope envelope, BasicProperties properties, byte[] body)
				throws IOException {

			String message = new String(body,"UTF8");
			System.out.printf("Message Received : %s%n", message);
		}

	}

}
