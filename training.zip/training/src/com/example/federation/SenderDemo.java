package com.example.federation;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo {

	public static void main(String[] args) throws Exception {
			
		ConnectionFactory connectionFactory = new ConnectionFactory();
		connectionFactory.setHost("localhost");
		connectionFactory.setPort(5672); //Upstream broker
		connectionFactory.setVirtualHost("/");
		connectionFactory.setUsername("guest");
		connectionFactory.setPassword("guest");
		
		Connection connection = connectionFactory.newConnection();
		System.out.println("Connected to Broker!!!!");
		Channel channel = connection.createChannel();
		
		channel.basicPublish("ex.stocks.daily", "", null, "Dell - $34500.000".getBytes());
		
		System.out.println("Message sending done!!!!");
		
		channel.close();
		connection.close();		
		System.out.println("Disconnected from Broker!!!!");

	}

}
