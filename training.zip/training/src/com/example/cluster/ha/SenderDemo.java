package com.example.cluster.ha;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo {

	public static void main(String[] args) throws Exception {
			
		ConnectionFactory connectionFactory = new ConnectionFactory();
		connectionFactory.setHost("localhost");
		connectionFactory.setPort(5674); //Slave Node
		connectionFactory.setVirtualHost("JLR");
		connectionFactory.setUsername("guest");
		connectionFactory.setPassword("guest");
		
		Connection connection = connectionFactory.newConnection();
		System.out.println("Connected to Broker!!!!");
		Channel channel = connection.createChannel();
		
		channel.basicPublish("EX.CARS", "LUXURY", null, "Jaguar XF 2015".getBytes());
		channel.basicPublish("EX.CARS", "LUXURY", null, "Jaguar XE 2015".getBytes());
		channel.basicPublish("EX.CARS", "LUXURY", null, "Jaguar XE 2016".getBytes());
		channel.basicPublish("EX.CARS", "LUXURY", null, "Jaguar XE 2016".getBytes());
		
		System.out.println("Message sending done!!!!");
		
		channel.close();
		connection.close();		
		System.out.println("Disconnected from Broker!!!!");

	}

}
