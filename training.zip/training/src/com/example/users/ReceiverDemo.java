package com.example.users;

import java.io.IOException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.rabbitmq.client.AMQP.BasicProperties;

public class ReceiverDemo {

	public static void main(String[] args) throws Exception {
		new ReceiverDemo();
	}

	public ReceiverDemo() throws Exception {

		// Step 1
		// Setup connection factory for RabbitMQ
		ConnectionFactory connectionFactory = new ConnectionFactory();
		connectionFactory.setHost("localhost");
		connectionFactory.setPort(5672);
		// connectionFactory.setVirtualHost("/");
		connectionFactory.setVirtualHost("WallMart");
		// connectionFactory.setVirtualHost("DBS");

		connectionFactory.setUsername("chicken");
		connectionFactory.setPassword("secret");

		// Step 2
		// Create a new connection from factory
		Connection connection = connectionFactory.newConnection();
		System.out.println("Connected to Broker!!!!");

		// Step 3
		// Create a new channel from connection
		Channel channel = connection.createChannel();

		// Step 4
		// Prepare a consumer to read message
		MessageConsumer consumer = new MessageConsumer(channel);

		// Step 5
		// Consume messages using channel with the defined consumer
		String QUEUE = "retail.order.north.q";
		channel.basicConsume(QUEUE, true, consumer);

		// Step 6
		// Close/Release channel and connection
		//channel.close();
		//connection.close();
		System.out.println("Disconnected from Broker!!!!");

	}

	class MessageConsumer extends DefaultConsumer {

		public MessageConsumer(Channel channel) {
			super(channel);
		}

		public void handleDelivery(String consumerTag, Envelope envelope, BasicProperties properties, byte[] body)
				throws IOException {

			String message = new String(body,"UTF8");
			System.out.printf("Message Received : %s%n", message);
		}

	}

}
