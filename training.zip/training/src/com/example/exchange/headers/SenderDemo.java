package com.example.exchange.headers;

import java.util.HashMap;
import java.util.Map;

import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo {

	public static void main(String[] args) throws Exception {

		ConnectionFactory connectionFactory = new ConnectionFactory();
		Connection connection = connectionFactory.newConnection();
		System.out.println("Connected to Broker!!!!");
		Channel channel = connection.createChannel();

		//Prepare headers
		Map<String, Object> customHeaders = new HashMap<>();
		//customHeaders.put("lang", "en");
		//customHeaders.put("country", "india");
		//customHeaders.put("type", "crime");
		customHeaders.put("type", "politics");
		
		BasicProperties headers = new BasicProperties();
		headers = headers.builder().headers(customHeaders).build();
		
		//channel.basicPublish("news", "", headers, "5 murders in last 7 days".getBytes());
		channel.basicPublish("news", "", headers, "Politics is a good business".getBytes());

		System.out.println("Message sending done!!!!");

		channel.close();
		connection.close();
		System.out.println("Disconnected from Broker!!!!");

	}

}
