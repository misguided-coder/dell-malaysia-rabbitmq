package com.example.exchange.topic;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo1 {

	public static void main(String[] args) throws Exception {

		ConnectionFactory connectionFactory = new ConnectionFactory();
		Connection connection = connectionFactory.newConnection();
		System.out.println("Connected to Broker!!!!");
		Channel channel = connection.createChannel();

		//channel.basicPublish("ex.cars", "car.bmw.2020", null, "BMW X6".getBytes());
		//channel.basicPublish("ex.cars", "car.hyundai.2020.latest", null, "Hyundai Palisade 2020".getBytes());
		//channel.basicPublish("ex.cars", "car.hyundai.2022", null, "Hyundai Palisade 2022".getBytes());
		//channel.basicPublish("ex.cars", "car.hyundai", null, "Hyundai Palisade concept".getBytes());
		//channel.basicPublish("ex.cars", "car.old.sedan.costly", null, "Merc E Class".getBytes());
		channel.basicPublish("ex.cars", "car.old.sedan", null, "Merc E Class".getBytes());
		
		System.out.println("Message sending done!!!!");

		channel.close();
		connection.close();
		System.out.println("Disconnected from Broker!!!!");

	}

}
