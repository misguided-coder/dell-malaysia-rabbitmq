package com.example.queue.lazymode;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

//Demo to check lazy mode of queue
public class SenderDemo {

	public static void main(String[] args) throws Exception {

		ConnectionFactory connectionFactory = new ConnectionFactory();
		Connection connection = connectionFactory.newConnection();
		System.out.println("Connected to Broker!!!!");
		Channel channel = connection.createChannel();

		for (int i = 1; i <= 50; i++) {
			channel.basicPublish("", "songs", null, ("Song-"+i).getBytes());
		}

		System.out.println("Message sending done!!!!");

		channel.close();
		connection.close();
		System.out.println("Disconnected from Broker!!!!");

	}

}
