package com.example.queue.persistent;

import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

//Demo to check message delivery mode (persistent/non-persistent)
public class SenderDemo {

	public static void main(String[] args) throws Exception {

		ConnectionFactory connectionFactory = new ConnectionFactory();
		Connection connection = connectionFactory.newConnection();
		System.out.println("Connected to Broker!!!!");
		Channel channel = connection.createChannel();

		BasicProperties headers = new BasicProperties();
		headers = headers.builder().deliveryMode(2).build();

		for (int i = 1; i <= 10; i++) {
			channel.basicPublish("", "tutions", headers, "Lets study Maths".getBytes());
		}

		headers = headers.builder().deliveryMode(1).build();

		for (int i = 1; i <= 5; i++) {
			channel.basicPublish("", "tutions", headers, "Lets study Physics".getBytes());
		}

		System.out.println("Message sending done!!!!");

		channel.close();
		connection.close();
		System.out.println("Disconnected from Broker!!!!");

	}

}
