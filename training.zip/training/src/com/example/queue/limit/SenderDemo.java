package com.example.queue.limit;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

//Demo to check queue limit (quota limit)
public class SenderDemo {

	public static void main(String[] args) throws Exception {

		ConnectionFactory connectionFactory = new ConnectionFactory();
		Connection connection = connectionFactory.newConnection();
		System.out.println("Connected to Broker!!!!");
		Channel channel = connection.createChannel();

		/*channel.basicPublish("", "passport.q", null, "Person 1 waiting for passport application".getBytes());
		channel.basicPublish("", "passport.q", null, "Person 2 waiting for passport application".getBytes());
		channel.basicPublish("", "passport.q", null, "Person 3 waiting for passport application".getBytes());
		channel.basicPublish("", "passport.q", null, "Person 4 waiting for passport application".getBytes());
		channel.basicPublish("", "passport.q", null, "Person 5 waiting for passport application".getBytes());
		*/
		
		//channel.basicPublish("", "passport.q", null, "Person 6 waiting for passport application".getBytes());
		//channel.basicPublish("", "passport.q", null, "Person 7 waiting for passport application".getBytes());
		
		  
		/*channel.basicPublish("", "passport.renewal.q", null, "Person 1 waiting for passport renewal".getBytes());
		channel.basicPublish("", "passport.renewal.q", null, "Person 2 waiting for passport renewal".getBytes());
		channel.basicPublish("", "passport.renewal.q", null, "Person 3 waiting for passport renewal".getBytes());
		*/
		
		/*channel.basicPublish("", "passport.update.q", null, "Person 1 waiting for address change".getBytes());
		channel.basicPublish("", "passport.update.q", null, "Person 2 waiting for address change".getBytes());
		channel.basicPublish("", "passport.update.q", null, "Person 3 waiting for address change".getBytes());
		channel.basicPublish("", "passport.update.q", null, "Person 4 waiting for address change".getBytes());
		*/
		
		channel.basicPublish("", "passport.vvip.q", null, "Officer want passport in 20 days".getBytes());
		
		System.out.println("Message sending done!!!!");

		channel.close();
		connection.close();
		System.out.println("Disconnected from Broker!!!!");

	}

}
