package com.example.queue.priority;

import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

//Demo to deliver message as per high/low priority rather FIFO
public class SenderDemo {

	public static void main(String[] args) throws Exception {

		ConnectionFactory connectionFactory = new ConnectionFactory();
		Connection connection = connectionFactory.newConnection();
		System.out.println("Connected to Broker!!!!");
		Channel channel = connection.createChannel();

		BasicProperties headers = new BasicProperties();
		headers = headers.builder().priority(5).build();

		channel.basicPublish("", "orders.q", headers, "Order 1 --- 10 Chocolates".getBytes());
		channel.basicPublish("", "orders.q", headers, "Order 2 --- 5 Burgers".getBytes());

		headers = headers.builder().priority(10).build();

		channel.basicPublish("", "orders.q", headers, "Order 3 --- 5 Pizzas".getBytes());
		channel.basicPublish("", "orders.q", headers, "Order 4 --- 2 Cold Drinks".getBytes());

		System.out.println("Message sending done!!!!");

		channel.close();
		connection.close();
		System.out.println("Disconnected from Broker!!!!");

	}

}
